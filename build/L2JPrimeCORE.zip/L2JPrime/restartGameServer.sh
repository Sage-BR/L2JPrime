#!/bin/bash

java -Dfile.encoding=UTF- -cp lib/*:l2jprime-core.jar com.l2jprime.gameserver.powerpak.xmlrpc.XMLRPCClient_ManagementTester

